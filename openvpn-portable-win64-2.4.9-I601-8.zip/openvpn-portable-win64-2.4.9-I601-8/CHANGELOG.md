# Changelog

## 2.4.9-I601-8 (2020/04/25)

* OpenVPN 2.4.9-I601
* Fix registry import (#4)
* Portapps 2.2.2

## 2.4.8-I602-7 (2019/11/06)

* OpenVPN 2.4.8-I602

## 2.4.7-I607-6 (2019/11/06)

* OpenVPN 2.4.7-I607
* Portapps 1.30.0

## 2.4.7-I607-Win10-5 (2019/05/18)

* OpenVPN 2.4.7-I607-Win10

## 2.4.7-I607-Win7-4 (2019/05/18)

* OpenVPN 2.4.7-I607-Win7
* Portapps 1.24.1

## 2.4.7-I601-3 (2019/03/19)

* Portapps 1.20.3

## 2.4.7-I601-2 (2019/02/21)

* OpenVPN 2.4.7-I601
* Add checksums (portapps/portapps#11)

## 2.4.6-I602-1 (2018/09/29)

* Initial version based on OpenVPN 2.4.6-I602
